// Enable Bootstrap tooltips
document.addEventListener('DOMContentLoaded', function() {
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    var tooltipList = tooltipTriggerList.map(function(tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });

    // Auto-hide alerts after 5 seconds
    var alerts = document.querySelectorAll('.alert');
    alerts.forEach(function(alert) {
        setTimeout(function() {
            var bsAlert = new bootstrap.Alert(alert);
            bsAlert.close();
        }, 5000);
    });

    // Handle forms that should show waiting page
    document.querySelectorAll('form[data-show-waiting]').forEach(function(form) {
        form.addEventListener('submit', function() {
            // Store the current page URL in session storage
            sessionStorage.setItem('returnUrl', window.location.href);
            // Redirect to waiting page
            window.location.href = '/waiting/';
            return true;
        });
    });

    // Check if we're on the waiting page and should redirect back
    if (window.location.pathname === '/waiting/') {
        const returnUrl = sessionStorage.getItem('returnUrl');
        if (returnUrl) {
            sessionStorage.removeItem('returnUrl');
            setTimeout(function() {
                window.location.href = returnUrl;
            }, 3000); // Redirect after 3 seconds
        }
    }
}); 