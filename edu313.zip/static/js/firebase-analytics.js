// Firebase configuration
const firebaseConfig = {
    // Replace with your Firebase config
    apiKey: "YOUR_API_KEY",
    authDomain: "your-app.firebaseapp.com",
    projectId: "your-app",
    storageBucket: "your-app.appspot.com",
    messagingSenderId: "your-sender-id",
    appId: "your-app-id",
    measurementId: "your-measurement-id"
};

// Initialize Firebase
firebase.initializeApp(firebaseConfig);
const analytics = firebase.analytics();

// Track page views
document.addEventListener('DOMContentLoaded', function() {
    analytics.logEvent('page_view', {
        page_title: document.title,
        page_location: window.location.href,
        page_path: window.location.pathname
    });
});

// Track user interactions
function trackEvent(eventName, params = {}) {
    analytics.logEvent(eventName, params);
}

// Add event listeners for important interactions
document.addEventListener('DOMContentLoaded', function() {
    // Track course enrollment
    const enrollButtons = document.querySelectorAll('.enroll-button');
    enrollButtons.forEach(button => {
        button.addEventListener('click', function() {
            const courseId = this.dataset.courseId;
            const courseTitle = this.dataset.courseTitle;
            trackEvent('course_enrollment', {
                course_id: courseId,
                course_title: courseTitle
            });
        });
    });

    // Track lesson completion
    const lessonCompleteButtons = document.querySelectorAll('.lesson-complete-button');
    lessonCompleteButtons.forEach(button => {
        button.addEventListener('click', function() {
            const lessonId = this.dataset.lessonId;
            const lessonTitle = this.dataset.lessonTitle;
            trackEvent('lesson_completed', {
                lesson_id: lessonId,
                lesson_title: lessonTitle
            });
        });
    });

    // Track video interactions
    const videoPlayers = document.querySelectorAll('.video-container iframe');
    videoPlayers.forEach(player => {
        // YouTube iframe API events
        player.addEventListener('onStateChange', function(event) {
            if (event.data === YT.PlayerState.PLAYING) {
                trackEvent('video_start', {
                    video_id: player.dataset.videoId,
                    lesson_id: player.dataset.lessonId
                });
            }
        });
    });
}); 