document.addEventListener('DOMContentLoaded', function() {
    // Create a bait element
    const bait = document.createElement('div');
    bait.className = 'ad-banner';
    bait.style.display = 'none';
    document.body.appendChild(bait);

    // Check if the bait element is hidden by AdBlock
    setTimeout(function() {
        const isAdBlockEnabled = window.getComputedStyle(bait).display === 'none';
        if (isAdBlockEnabled) {
            const warning = document.createElement('div');
            warning.className = 'adblock-warning';
            warning.innerHTML = `
                <strong>AdBlock Detected!</strong>
                <p>Please disable AdBlock or use a VPN to ensure all features work correctly.</p>
                <button class="btn btn-light btn-sm" onclick="this.parentElement.style.display='none'">
                    Dismiss
                </button>
            `;
            document.body.insertBefore(warning, document.body.firstChild);
            warning.style.display = 'block';
        }
        bait.remove();
    }, 100);
}); 