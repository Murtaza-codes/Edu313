/**
 * Custom Admin JS Enhancements
 * Adds glassy effects, Bootstrap compatibility, and improves mobile responsiveness
 * Version 2.0 - Bootstrap Integration
 */
document.addEventListener('DOMContentLoaded', function() {
    // Create mobile menu toggle button only if it doesn't exist
    if (!document.querySelector('.menu-toggle')) {
        const menuToggle = document.createElement('button');
        menuToggle.className = 'menu-toggle';
        menuToggle.innerHTML = '<i class="fas fa-bars"></i>';
        menuToggle.setAttribute('aria-label', 'Toggle Menu');
        document.body.appendChild(menuToggle);
        
        // Find sidebar - use standard Django admin sidebar
        const sidebar = document.querySelector('#nav-sidebar');
        
        if (sidebar) {
            // Ensure auth app models are visible
            const authModels = sidebar.querySelectorAll('.model-user, .model-group');
            authModels.forEach(model => {
                model.style.display = 'block';
            });
            
            // Toggle sidebar on menu button click
            menuToggle.addEventListener('click', function() {
                sidebar.classList.toggle('show');
            });
            
            // Close sidebar when clicking outside
            document.addEventListener('click', function(e) {
                if (!sidebar.contains(e.target) && e.target !== menuToggle) {
                    sidebar.classList.remove('show');
                }
            });
        }
    }
    
    // Fix standard Django tables to be responsive by wrapping them in a container
    const djangoTables = document.querySelectorAll('.module table, .results');
    djangoTables.forEach(table => {
        // Skip if already wrapped
        if (!table.parentElement.classList.contains('table-container')) {
            const wrapper = document.createElement('div');
            wrapper.className = 'table-container';
            table.parentNode.insertBefore(wrapper, table);
            wrapper.appendChild(table);
        }
    });
    
    // Add Font Awesome if not already present
    if (!document.querySelector('link[href*="fontawesome"]')) {
        const fontAwesomeLink = document.createElement('link');
        fontAwesomeLink.rel = 'stylesheet';
        fontAwesomeLink.href = 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css';
        document.head.appendChild(fontAwesomeLink);
    }
    
    // Add Google Fonts for Inter if not present
    if (!document.querySelector('link[href*="Inter"]')) {
        const googleFontsLink = document.createElement('link');
        googleFontsLink.rel = 'stylesheet';
        googleFontsLink.href = 'https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap';
        document.head.appendChild(googleFontsLink);
    }
    
    // Fix breadcrumbs for mobile
    const breadcrumbs = document.querySelector('.breadcrumbs');
    if (breadcrumbs) {
        breadcrumbs.style.overflowX = 'auto';
        breadcrumbs.style.whiteSpace = 'nowrap';
        breadcrumbs.style.padding = '0.5rem 0';
    }
    
    // Add glassy effects to dashboard stats if on dashboard
    if (document.querySelector('.dashboard')) {
        addDashboardStats();
    }
    
    // Fix auth app display issues
    fixAuthAppDisplay();

    // Initialize Bootstrap tooltips if Bootstrap exists
    if (typeof bootstrap !== 'undefined') {
        var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
        tooltipTriggerList.map(function (tooltipTriggerEl) {
            return new bootstrap.Tooltip(tooltipTriggerEl);
        });
    }

    // Make Bootstrap tables responsive
    const bootstrapTables = document.querySelectorAll('table.table:not(.table-responsive)');
    if (bootstrapTables.length > 0) {
        bootstrapTables.forEach(table => {
            if (!table.parentElement.classList.contains('table-responsive')) {
                const wrapper = document.createElement('div');
                wrapper.className = 'table-responsive';
                table.parentNode.insertBefore(wrapper, table);
                wrapper.appendChild(table);
            }
        });
    }

    // Add Bootstrap classes to Django admin elements
    const adminForm = document.querySelector('.admin-form');
    if (adminForm) {
        const inputs = adminForm.querySelectorAll('input[type="text"], input[type="password"], input[type="email"], input[type="number"], textarea, select');
        inputs.forEach(input => {
            input.classList.add('form-control');
        });

        const checkboxes = adminForm.querySelectorAll('input[type="checkbox"]');
        checkboxes.forEach(checkbox => {
            const wrapper = document.createElement('div');
            wrapper.className = 'form-check';
            checkbox.classList.add('form-check-input');
            checkbox.parentNode.insertBefore(wrapper, checkbox);
            wrapper.appendChild(checkbox);
            
            // If there's a label after the checkbox, make it a form-check-label
            if (checkbox.nextElementSibling && checkbox.nextElementSibling.tagName === 'LABEL') {
                const label = checkbox.nextElementSibling;
                wrapper.appendChild(label);
                label.classList.add('form-check-label');
            }
        });
    }

    // Handle theme settings from localStorage
    function setTheme() {
        const savedTheme = localStorage.getItem('admin_theme') || 'dark';
        document.documentElement.setAttribute('data-admin-theme', savedTheme);
    }

    setTheme();
});

/**
 * Adds dashboard stats to Django admin dashboard
 */
function addDashboardStats() {
    const dashboardModules = document.querySelectorAll('.dashboard .module');
    if (dashboardModules.length > 0) {
        // Create a stats wrapper
        const statsWrapper = document.createElement('div');
        statsWrapper.className = 'course-stats';
        
        // Create stats cards based on what's available
        const statsData = [];
        
        // Look for courses
        const courseCount = document.querySelectorAll('tr[class*="model-course"]').length;
        if (courseCount > 0) {
            statsData.push({ icon: 'fa-graduation-cap', label: 'Courses', value: courseCount });
        }
        
        // Look for lessons
        const lessonCount = document.querySelectorAll('tr[class*="model-lesson"]').length;
        if (lessonCount > 0) {
            statsData.push({ icon: 'fa-book', label: 'Lessons', value: lessonCount });
        }
        
        // Look for users
        const userCount = document.querySelectorAll('tr[class*="model-user"]').length;
        if (userCount > 0) {
            statsData.push({ icon: 'fa-users', label: 'Students', value: userCount });
        }
        
        // If we have no specific stats, add generic ones
        if (statsData.length === 0) {
            const appCount = document.querySelectorAll('#nav-sidebar .app-list .app').length;
            const modelCount = document.querySelectorAll('#nav-sidebar .model').length;
            
            statsData.push(
                { icon: 'fa-puzzle-piece', label: 'Apps', value: appCount },
                { icon: 'fa-database', label: 'Models', value: modelCount }
            );
        }
        
        // Build stats cards
        statsData.forEach(stat => {
            const statCard = document.createElement('div');
            statCard.className = 'stat-card';
            statCard.innerHTML = `
                <div class="stat-icon"><i class="fas ${stat.icon}"></i></div>
                <div class="stat-value">${stat.value}</div>
                <div class="stat-label">${stat.label}</div>
            `;
            statsWrapper.appendChild(statCard);
        });
        
        // Insert stats before first dashboard module
        const firstModule = dashboardModules[0];
        firstModule.parentNode.insertBefore(statsWrapper, firstModule);
    }
}

/**
 * Fixes auth app display issues
 */
function fixAuthAppDisplay() {
    // Check if we're on an auth app page
    if (document.body.classList.contains('app-auth') || 
        document.body.classList.contains('app-auth_user') || 
        document.body.classList.contains('app-auth_group')) {
        
        // Fix main content area
        const main = document.querySelector('.main');
        if (main) {
            main.style.marginLeft = '0';
        }
        
        // Fix content margin
        const content = document.querySelector('#content');
        if (content) {
            content.style.marginLeft = '0';
            content.style.padding = '2rem';
        }
    }
} 