// Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyBfuj6Bqe_rThfleLtm434JvEWoeCeRBnU",
  authDomain: "afedu313.firebaseapp.com",
  projectId: "afedu313",
  storageBucket: "afedu313.appspot.com",
  messagingSenderId: "43546744324",
  appId: "1:43546744324:web:7e2deb6ea57f74e751c751",
  measurementId: "G-1L8QXH2C2V"
};

// Initialize Firebase
if (!firebase.apps.length) {
  firebase.initializeApp(firebaseConfig);
}

// Export the auth object for use in other scripts
const auth = firebase.auth(); 