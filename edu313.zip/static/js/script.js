// Enable Bootstrap tooltips
document.addEventListener('DOMContentLoaded', function() {
    // Initialize Bootstrap components
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    var tooltipList = tooltipTriggerList.map(function(tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });

    // Auto-hide alerts after 5 seconds
    var alerts = document.querySelectorAll('.alert');
    alerts.forEach(function(alert) {
        setTimeout(function() {
            var bsAlert = new bootstrap.Alert(alert);
            bsAlert.close();
        }, 5000);
    });

    // Handle forms that should show waiting page
    document.querySelectorAll('form[data-show-waiting]').forEach(function(form) {
        form.addEventListener('submit', function() {
            // Store the current page URL in session storage
            sessionStorage.setItem('returnUrl', window.location.href);
            // Redirect to waiting page
            window.location.href = '/waiting/';
            return true;
        });
    });

    // Check if we're on the waiting page and should redirect back
    if (window.location.pathname === '/waiting/') {
        const returnUrl = sessionStorage.getItem('returnUrl');
        if (returnUrl) {
            sessionStorage.removeItem('returnUrl');
            setTimeout(function() {
                window.location.href = returnUrl;
            }, 3000); // Redirect after 3 seconds
        }
    }
    
    // Theme Switcher
    const themeToggle = document.getElementById('theme-toggle');
    const themeToggleCheckbox = document.getElementById('theme-toggle-checkbox');
    const lightOption = document.querySelector('.theme-toggle-option.light');
    const darkOption = document.querySelector('.theme-toggle-option.dark');
    
    // Function to set the theme
    function setTheme(theme) {
        console.log('Setting theme to:', theme);
        
        // Set on HTML element
        document.documentElement.setAttribute('data-theme', theme);
        
        // Store preference
        localStorage.setItem('theme', theme);
        
        // Update the toggle UI
        if (themeToggle) {
            themeToggle.setAttribute('data-theme', theme);
            
            // Update checkbox state
            if (themeToggleCheckbox) {
                themeToggleCheckbox.checked = (theme === 'light');
            }
        }
        
        // Update navbar classes for better visibility
        const navbar = document.querySelector('.navbar');
        if (navbar) {
            if (theme === 'light') {
                navbar.classList.remove('navbar-dark');
                navbar.classList.add('navbar-light');
            } else {
                navbar.classList.remove('navbar-light');
                navbar.classList.add('navbar-dark');
            }
        }
    }
    
    // Add click handlers to the specific sections of the toggle
    if (lightOption) {
        lightOption.addEventListener('click', function(e) {
            e.stopPropagation();
            setTheme('light');
        });
    }
    
    if (darkOption) {
        darkOption.addEventListener('click', function(e) {
            e.stopPropagation();
            setTheme('dark');
        });
    }
    
    // Check for saved theme preference or use device preference
    const savedTheme = localStorage.getItem('theme');
    
    if (savedTheme) {
        setTheme(savedTheme);
    } else {
        // Use device preference if available
        const prefersDarkScheme = window.matchMedia('(prefers-color-scheme: dark)');
        if (prefersDarkScheme.matches) {
            setTheme('dark');
        } else {
            setTheme('light');
        }
    }
    
    // Toggle theme when the switch is clicked (fallback)
    if (themeToggle) {
        themeToggle.addEventListener('click', function() {
            // Read current theme directly from HTML
            const currentTheme = document.documentElement.getAttribute('data-theme') || 'dark';
            const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
            setTheme(newTheme);
        });
        
        // For accessibility - also handle checkbox changes
        if (themeToggleCheckbox) {
            themeToggleCheckbox.addEventListener('change', function(e) {
                e.stopPropagation(); // Prevent triggering the themeToggle click event
                setTheme(this.checked ? 'light' : 'dark');
            });
        }
    }
}); 