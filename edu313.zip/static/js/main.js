document.addEventListener('DOMContentLoaded', function() {
    // Content protection
    const protectedContent = document.querySelectorAll('.protected-content');
    protectedContent.forEach(content => {
        // Disable right-click
        content.addEventListener('contextmenu', e => e.preventDefault());
        
        // Disable keyboard shortcuts
        content.addEventListener('keydown', e => {
            if ((e.ctrlKey || e.metaKey) && 
                (e.key === 'c' || e.key === 'C' || 
                 e.key === 'u' || e.key === 'U' ||
                 e.key === 's' || e.key === 'S')) {
                e.preventDefault();
                return false;
            }
        });
    });

    // Progress tracking
    const videoContainers = document.querySelectorAll('.video-container');
    videoContainers.forEach(container => {
        const iframe = container.querySelector('iframe');
        if (iframe) {
            // Create YouTube player
            const player = new YT.Player(iframe, {
                events: {
                    'onStateChange': onPlayerStateChange
                }
            });

            // Track video progress
            function onPlayerStateChange(event) {
                if (event.data === YT.PlayerState.ENDED) {
                    const lessonId = iframe.dataset.lessonId;
                    markLessonComplete(lessonId);
                }
            }
        }
    });

    // Mark lesson as complete
    function markLessonComplete(lessonId) {
        fetch('/courses/mark-complete/', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRFToken': getCookie('csrftoken')
            },
            body: JSON.stringify({
                lesson_id: lessonId
            })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                updateProgressUI(lessonId);
            }
        });
    }

    // Update progress UI
    function updateProgressUI(lessonId) {
        const progressBar = document.querySelector(`[data-lesson-progress="${lessonId}"]`);
        if (progressBar) {
            progressBar.classList.add('completed');
            
            // Update course progress
            const courseProgress = document.querySelector('.course-progress');
            if (courseProgress) {
                const total = courseProgress.dataset.total;
                const completed = document.querySelectorAll('.lesson-progress.completed').length;
                const percentage = (completed / total) * 100;
                courseProgress.style.width = `${percentage}%`;
                courseProgress.setAttribute('aria-valuenow', percentage);
            }
        }
    }

    // Helper function to get CSRF token
    function getCookie(name) {
        let cookieValue = null;
        if (document.cookie && document.cookie !== '') {
            const cookies = document.cookie.split(';');
            for (let i = 0; i < cookies.length; i++) {
                const cookie = cookies[i].trim();
                if (cookie.substring(0, name.length + 1) === (name + '=')) {
                    cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                    break;
                }
            }
        }
        return cookieValue;
    }

    // Initialize tooltips
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });

    // Initialize popovers
    const popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'));
    popoverTriggerList.map(function (popoverTriggerEl) {
        return new bootstrap.Popover(popoverTriggerEl);
    });
}); 