import firebase_admin
from firebase_admin import credentials, auth
import os
import json

def initialize_firebase():
    """Initialize Firebase Admin SDK"""
    try:
        # Check if already initialized
        app = firebase_admin.get_app()
        print("Firebase already initialized")
        return app
    except ValueError:
        print("Initializing Firebase Admin SDK")
        # Initialize with default service account
        # In production, you would use a proper service account file
        try:
            # For local development, you might have a service account file
            cred_path = os.path.join(os.path.dirname(__file__), 'firebase-service-account.json')
            if os.path.exists(cred_path):
                print(f"Using service account file: {cred_path}")
                cred = credentials.Certificate(cred_path)
                return firebase_admin.initialize_app(cred)
            else:
                print("Service account file not found, using application default credentials")
                return firebase_admin.initialize_app()
        except Exception as init_error:
            print(f"Firebase initialization error: {init_error}")
            # Fallback to application default credentials
            return firebase_admin.initialize_app()
    
def verify_id_token(id_token):
    """Verify Firebase ID token"""
    try:
        # Initialize Firebase if not already initialized
        initialize_firebase()
        
        print(f"Verifying token: {id_token[:10]}...")
        
        # Verify token
        decoded_token = auth.verify_id_token(id_token)
        
        # Log successful verification
        if decoded_token:
            print(f"Token verified successfully for user: {decoded_token.get('email')}")
            # Print some parts of the token for debugging
            if 'email' in decoded_token:
                print(f"Email: {decoded_token['email']}")
            if 'email_verified' in decoded_token:
                print(f"Email verified: {decoded_token['email_verified']}")
            if 'uid' in decoded_token:
                print(f"UID: {decoded_token['uid']}")
        
        return decoded_token
    except auth.InvalidIdTokenError:
        print("Invalid ID token")
        return None
    except auth.ExpiredIdTokenError:
        print("Expired ID token")
        return None
    except auth.RevokedIdTokenError:
        print("Revoked ID token")
        return None
    except auth.CertificateFetchError:
        print("Certificate fetch error")
        return None
    except Exception as e:
        print(f"Error verifying token: {e}")
        return None 