from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static
from accounts import views as accounts_views
from django.conf.urls.i18n import i18n_patterns
from django.utils.translation import gettext_lazy as _
from django.shortcuts import redirect
from django.utils.translation import get_language, activate, gettext
from django.contrib.auth import views as auth_views

# Helper function to redirect to proper language paths with correct translation
def redirect_to_language_url(request, path_name):
    """
    Redirects to the correct URL with language prefix and proper translation
    """
    lang_code = request.LANGUAGE_CODE
    # Temporarily activate the user's language to get the correct translation
    current_lang = get_language()
    activate(lang_code)
    # Get the translated path
    if path_name == 'register':
        translated_path = gettext('register/')
    elif path_name == 'login':
        translated_path = gettext('login/')
    elif path_name == 'dashboard':
        translated_path = gettext('dashboard/')
    elif path_name == 'accounts':
        translated_path = gettext('accounts/')
    elif path_name == 'admin':
        translated_path = gettext('admin/')
    else:
        translated_path = path_name + '/'
    # Restore the original language
    activate(current_lang)
    # Create the redirect URL
    redirect_url = f'/{lang_code}/{translated_path}'
    # Remove any double slashes
    redirect_url = redirect_url.replace('//', '/')
    return redirect(redirect_url)

# URLs without language prefix
urlpatterns = [
    path('i18n/', include('django.conf.urls.i18n')),  # For language switching
    path('rosetta/', include('rosetta.urls')),  # Translation interface
    
    # Common redirect for users who forget language prefix
    path('register/', lambda request: redirect_to_language_url(request, 'register')),
    path('login/', lambda request: redirect_to_language_url(request, 'login')),
    path('dashboard/', lambda request: redirect_to_language_url(request, 'dashboard')),
    path('courses/', lambda request: redirect_to_language_url(request, 'courses')),
    path('contact/', lambda request: redirect_to_language_url(request, 'contact')),
    path('about/', lambda request: redirect_to_language_url(request, 'about')),
    
    # Admin redirect
    path('admin/', lambda request: redirect_to_language_url(request, 'admin')),
]

# URLs with language prefix
urlpatterns += i18n_patterns(
    path('admin/', admin.site.urls),  # Standard admin URL (English)
    path(_('admin/'), admin.site.urls),  # Translated admin URL (for Farsi: مدیریت/)
    path('', include('core.urls')),
    
    # Direct authentication URLs - must be before accounts path
    path(_('login/'), accounts_views.new_login_view, name='direct_login'),
    path(_('register/'), accounts_views.new_register_view, name='direct_register'),
    
    # Password Reset URLs
    path('password_reset/', auth_views.PasswordResetView.as_view(), name='password_reset'),
    path('password_reset/done/', auth_views.PasswordResetDoneView.as_view(), name='password_reset_done'),
    path('reset/<uidb64>/<token>/', auth_views.PasswordResetConfirmView.as_view(), name='password_reset_confirm'),
    path('reset/done/', auth_views.PasswordResetCompleteView.as_view(), name='password_reset_complete'),
    
    # App URLs - accounts comes after the direct auth URLs
    path(_('accounts/'), include('accounts.urls')),
    path(_('courses/'), include('courses.urls')),
    path(_('dashboard/'), include('dashboard.urls')),
    
    prefix_default_language=True,  # Include prefix for default language
)

# Media files
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT) 