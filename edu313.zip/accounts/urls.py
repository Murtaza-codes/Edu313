from django.urls import path
from . import views

app_name = 'accounts'

urlpatterns = [
    # Main paths
    path('register/', views.register_view, name='register'),
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),
    
    # New paths 
    path('auth/signup/', views.new_register_view, name='new_register'),
    path('auth/signin/', views.new_login_view, name='new_login'),
    
    # Firebase integration endpoints
    path('firebase-register/', views.firebase_register, name='firebase_register'),
    path('firebase-login/', views.firebase_login, name='firebase_login'),
    
    # Email verification
    path('verify-email/<uidb64>/<token>/', views.verify_email_view, name='verify_email'),
    path('check-verification-status/', views.check_verification_status, name='check_verification_status'),
    
    # Profile
    path('profile/', views.profile_view, name='profile'),
    path('verification-required/', views.verification_required_view, name='verification_required'),
    
    # Admin Dashboard
    path('admin-dashboard/', views.admin_dashboard, name='admin_dashboard'),
    path('admin-dashboard/users/', views.user_management, name='user_management'),
    path('admin-dashboard/users/delete/<int:user_id>/', views.delete_user_view, name='delete_user'),
    
    # Verification endpoints
    path('auto-verify-email/', views.auto_verify_firebase_email, name='auto_verify_email'),
    path('refresh-verification/', views.refresh_firebase_verification, name='refresh_firebase_verification'),
    path('resend-verification-email/', views.resend_verification_email, name='resend_verification_email'),
]