from django.db import models
from django.contrib.auth.models import User
import uuid
from datetime import datetime, timedelta
from django.db.models.signals import pre_delete
from django.dispatch import receiver

class EmailVerificationToken(models.Model):
    """Model to store email verification tokens and status."""
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    token = models.UUIDField(default=uuid.uuid4, editable=False)
    created_at = models.DateTimeField(auto_now_add=True)
    expires_at = models.DateTimeField()
    verified = models.BooleanField(default=False)
    
    def __str__(self):
        return f"{self.user.username} - {'Verified' if self.verified else 'Not Verified'}"
    
    def is_expired(self):
        """Check if the token is expired."""
        return datetime.now().astimezone() > self.expires_at

class VerificationAttempt(models.Model):
    """Model to track verification attempts."""
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    ip_address = models.GenericIPAddressField(null=True, blank=True)
    timestamp = models.DateTimeField(auto_now_add=True)
    success = models.BooleanField(default=False)
    method = models.CharField(max_length=50, choices=[
        ('firebase_check', 'Firebase Check'),
        ('manual_resend', 'Manual Resend'),
        ('auto_check', 'Automatic Check'),
    ])
    error_message = models.TextField(blank=True, null=True)
    
    def __str__(self):
        return f"{self.user.username} - {self.timestamp} - {'Success' if self.success else 'Failed'}"
    
    class Meta:
        ordering = ['-timestamp']

class DeletedUserEmail(models.Model):
    """Track emails of deleted users to prevent re-registration"""
    email = models.EmailField(unique=True)
    deleted_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        verbose_name = "Deleted User Email"
        verbose_name_plural = "Deleted User Emails"
        ordering = ['-deleted_at']
    
    def __str__(self):
        return self.email

@receiver(pre_delete, sender=User)
def delete_firebase_user_signal(sender, instance, **kwargs):
    """Delete Firebase user when Django user is deleted"""
    try:
        email = instance.email
        from accounts.views import delete_firebase_user
        success, message = delete_firebase_user(email)
        print(f"Firebase user deletion: {success} - {message}")
        
        # Track the deleted email
        if email:
            DeletedUserEmail.objects.create(email=email)
    except Exception as e:
        print(f"Error in delete_firebase_user_signal: {e}") 