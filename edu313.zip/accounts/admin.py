from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from django.contrib.auth.models import User
from django.utils.translation import gettext_lazy as _
from django.utils.html import format_html
from django.urls import path, reverse
from django.http import HttpResponseRedirect
from django.conf import settings
from django.contrib import messages
from .models import EmailVerificationToken, VerificationAttempt, DeletedUserEmail

# Custom filter for Firebase users
class FirebaseUserFilter(admin.SimpleListFilter):
    title = _('Authentication Method')
    parameter_name = 'auth_method'
    
    def lookups(self, request, model_admin):
        return (
            ('firebase', _('Firebase Users')),
            ('django', _('Django Users')),
        )
    
    def queryset(self, request, queryset):
        if self.value() == 'firebase':
            # Users with empty or null password are Firebase users
            return queryset.filter(password__isnull=True) | queryset.filter(password='')
        if self.value() == 'django':
            # Users with non-empty password are Django users
            return queryset.exclude(password='').exclude(password__isnull=True)

# Customize the User admin display
class CustomUserAdmin(UserAdmin):
    list_display = ('username', 'email', 'first_name', 'last_name', 'is_staff', 'date_joined', 'authentication_type', 'is_verified', 'actions_column')
    list_filter = ('is_staff', 'is_superuser', 'is_active', 'date_joined', FirebaseUserFilter)
    search_fields = ('username', 'email', 'first_name', 'last_name')
    ordering = ('-date_joined',)  # Show newest users first
    
    def get_urls(self):
        urls = super().get_urls()
        custom_urls = [
            path('delete/<int:user_id>/', self.admin_site.admin_view(self.delete_user_view), name='custom_user_delete'),
        ]
        return custom_urls + urls
    
    def delete_user_view(self, request, user_id):
        if request.method == 'POST':
            user = User.objects.get(id=user_id)
            if user.is_superuser and not request.user.is_superuser:
                messages.error(request, _("You don't have permission to delete a superuser."))
                return HttpResponseRedirect(reverse('admin:auth_user_changelist'))
                
            username = user.username
            user.delete()
            messages.success(request, _(f"User '{username}' has been deleted successfully."))
            return HttpResponseRedirect(reverse('admin:auth_user_changelist'))
        
        return HttpResponseRedirect(reverse('admin:auth_user_changelist'))
    
    # Add custom field to show authentication type
    def authentication_type(self, obj):
        if obj.password is None or obj.password == '':
            return 'Firebase'
        return 'Django'
    authentication_type.short_description = 'Auth Type'
    
    # Add custom field to show verification status
    def is_verified(self, obj):
        try:
            return obj.emailverificationtoken.verified
        except:
            return False
    is_verified.boolean = True
    is_verified.short_description = 'Email Verified'
    
    # Add custom actions column with delete button
    def actions_column(self, obj):
        delete_url = reverse('admin:custom_user_delete', args=[obj.pk])
        change_url = reverse('admin:auth_user_change', args=[obj.pk])
        
        # Note: We're not using csrf token here because this is rendered in a changelist
        # and the admin handles CSRF. When the form is submitted the admin will add the token.
        return format_html(
            '<div class="user-actions">'
            '<a href="{}" class="user-action-button edit"><i class="fa fa-edit"></i> {}</a>'
            '<form method="post" action="{}" onsubmit="return confirm(\'{}\');" style="display:inline;">'
            '<button type="submit" class="user-delete-button"><i class="fa fa-trash"></i> {}</button>'
            '</form>'
            '</div>',
            change_url, _('Edit'),
            delete_url, _('Are you sure you want to delete this user?'),
            _('Delete')
        )
    actions_column.short_description = _('Actions')
    actions_column.allow_tags = True
    
    # Fieldsets for adding/editing users
    fieldsets = (
        (None, {'fields': ('username', 'password')}),
        ('Personal info', {'fields': ('first_name', 'last_name', 'email')}),
        ('Permissions', {
            'fields': ('is_active', 'is_staff', 'is_superuser', 'groups', 'user_permissions'),
        }),
        ('Important dates', {'fields': ('last_login', 'date_joined')}),
    )

# Email Verification Token Admin
class EmailVerificationTokenAdmin(admin.ModelAdmin):
    list_display = ('user', 'created_at', 'expires_at', 'verified')
    list_filter = ('verified',)
    search_fields = ('user__username', 'user__email')
    date_hierarchy = 'created_at'
    readonly_fields = ('token',)

# Verification Attempt Admin
class VerificationAttemptAdmin(admin.ModelAdmin):
    list_display = ('user', 'method', 'success', 'timestamp', 'ip_address')
    list_filter = ('success', 'method', 'timestamp')
    search_fields = ('user__username', 'user__email', 'ip_address', 'error_message')
    date_hierarchy = 'timestamp'
    readonly_fields = ('user', 'method', 'success', 'timestamp', 'ip_address', 'error_message')

# Deleted User Email Admin
class DeletedUserEmailAdmin(admin.ModelAdmin):
    list_display = ('email', 'deleted_at')
    search_fields = ('email',)
    date_hierarchy = 'deleted_at'
    readonly_fields = ('email', 'deleted_at')

# Unregister the default UserAdmin and register our custom one
admin.site.unregister(User)
admin.site.register(User, CustomUserAdmin)
admin.site.register(EmailVerificationToken, EmailVerificationTokenAdmin)
admin.site.register(VerificationAttempt, VerificationAttemptAdmin)
admin.site.register(DeletedUserEmail, DeletedUserEmailAdmin) 