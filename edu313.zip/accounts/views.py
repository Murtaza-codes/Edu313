from django.shortcuts import render, redirect
from django.contrib.auth import login, authenticate, logout
from django.contrib.auth.forms import UserCreationForm
from django.contrib import messages
from django.http import HttpResponse, JsonResponse
from django.middleware.csrf import get_token
from django.contrib.auth.models import User
from django.contrib.auth.password_validation import validate_password
from django.core.exceptions import ValidationError
from django.utils.translation import gettext as _
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_POST
from django.core.mail import send_mail
from django.conf import settings
from django.urls import reverse
from django.contrib.auth.decorators import login_required
from django.utils.http import urlsafe_base64_encode, urlsafe_base64_decode
from django.utils.encoding import force_bytes, force_str
from django.contrib.auth.tokens import default_token_generator
from django.template.loader import render_to_string
from django.utils.html import strip_tags
import json
import requests
import logging

from edusite.firebase import verify_id_token
from .models import EmailVerificationToken, VerificationAttempt
from datetime import datetime, timedelta
from django.core.paginator import Paginator
from django.db.models import Q

# Configure logger
logger = logging.getLogger(__name__)

# Decorator to check if email is verified
def email_verified_required(view_func):
    """Decorator that checks if user's email is verified."""
    def wrapper(request, *args, **kwargs):
        # If user is not logged in, proceed to the view
        # (the login_required decorator should catch this)
        if not request.user.is_authenticated:
            return view_func(request, *args, **kwargs)
            
        # For all users, check verification status
        try:
            # First check user.email_verified field
            if hasattr(request.user, 'email_verified') and request.user.email_verified:
                return view_func(request, *args, **kwargs)
                
            # Then check verification token
            verification_token = EmailVerificationToken.objects.filter(user=request.user).first()
            
            # If no token exists, create one with verified=False
            if not verification_token:
                verification_token = EmailVerificationToken.objects.create(
                    user=request.user,
                    verified=False,  # Not verified by default
                    expires_at=datetime.now() + timedelta(hours=48)
                )
            
            # If user is not verified, redirect to verification required page
            if not verification_token.verified:
                messages.warning(request, _('Your email needs to be verified before accessing this page.'))
                return redirect('accounts:verification_required')
            
            # User is verified, allow access to the content
            return view_func(request, *args, **kwargs)
            
        except Exception as e:
            # If there's an error checking verification, default to requiring verification
            print(f"Error checking verification: {str(e)}")
            messages.error(request, _('An error occurred checking your verification status.'))
            return redirect('accounts:verification_required')
            
    return wrapper

def send_verification_email(user, request):
    """This function is no longer used since Firebase handles email verification"""
    # We'll keep this function but mark it as deprecated
    print("WARNING: Deprecated email verification method called. Firebase now handles verification.")

def verify_email_view(request, uidb64, token):
    """View to handle email verification links."""
    try:
        # Decode the uidb64 to get the user ID
        from django.utils.http import urlsafe_base64_decode
        from django.utils.encoding import force_str
        
        uid = force_str(urlsafe_base64_decode(uidb64))
        user = User.objects.get(pk=uid)
        
        # Check if token is valid
        from django.contrib.auth.tokens import default_token_generator
        if default_token_generator.check_token(user, token):
            # Mark user as verified
            if hasattr(user, 'email_verified'):
                user.email_verified = True
                user.save()
            
            # Update or create verification token
            verification_token = EmailVerificationToken.objects.filter(user=user).first()
            if verification_token:
                verification_token.verified = True
                verification_token.save()
            else:
                EmailVerificationToken.objects.create(
                    user=user,
                    verified=True,
                    expires_at=datetime.now() + timedelta(hours=48)
                )
            
            # Log the verification
            ip_address = request.META.get('REMOTE_ADDR', None)
            VerificationAttempt.objects.create(
                user=user,
                ip_address=ip_address,
                success=True,
                method='email_link',
                error_message=None
            )
            
            messages.success(request, _('Your email has been successfully verified! You can now access all features of the site.'))
            
            # If user is already logged in, redirect to dashboard
            if request.user.is_authenticated:
                return redirect('dashboard:home')
            else:
                return redirect('accounts:login')
        else:
            # Token is invalid or expired
            messages.error(request, _('The verification link is invalid or has expired. Please request a new verification email.'))
            return redirect('accounts:verification_required')
    except (TypeError, ValueError, OverflowError, User.DoesNotExist) as e:
        # Log the error
        print(f"Email verification error: {str(e)}")
        messages.error(request, _('An error occurred during verification. Please try again or contact support.'))
        return redirect('accounts:verification_required')

def logout_view(request):
    """Handle user logout."""
    logout(request)
    messages.info(request, 'You have been logged out successfully.')
    return redirect('core:home')

def register_view(request):
    """Register view function - redirects to new_register_view."""
    return redirect('direct_register')

def login_view(request):
    """Login view function - redirects to new_login_view."""
    return redirect('direct_login')

def new_register_view(request):
    """Improved register view with Firebase integration."""
    return render(request, 'accounts/register_direct.html')

def new_login_view(request):
    """Improved login view with Firebase integration."""
    return render(request, 'accounts/login_direct.html')

@login_required
def profile_view(request):
    """User profile view for viewing and editing account information."""
    if request.method == 'POST':
        # Get form data
        first_name = request.POST.get('first_name')
        last_name = request.POST.get('last_name')
        username = request.POST.get('username')
        
        # Validate username uniqueness if changed
        if username != request.user.username and User.objects.filter(username=username).exists():
            messages.error(request, _('Username already taken. Please choose another one.'))
            return redirect('accounts:profile')
        
        # Update user information
        user = request.user
        user.first_name = first_name
        user.last_name = last_name
        user.username = username
        user.save()
        
        messages.success(request, _('Profile updated successfully.'))
        return redirect('accounts:profile')
    
    # Get Firebase auth status
    is_firebase_user = request.user.password is None or request.user.password == ''
    
    # Get email verification status
    is_email_verified = False
    
    # Check if user's email is verified in the email_verified field
    if hasattr(request.user, 'email_verified') and request.user.email_verified:
        is_email_verified = True
    else:
        # Check verification token
        verification_token = EmailVerificationToken.objects.filter(user=request.user).first()
        
        if verification_token:
            is_email_verified = verification_token.verified
        
        # If no verification token exists, create one with verified=False
        if not verification_token:
            verification_token = EmailVerificationToken.objects.create(
                user=request.user,
                verified=False,  # Not verified by default
                expires_at=datetime.now() + timedelta(hours=48)
            )
    
    context = {
        'user': request.user,
        'is_firebase_user': is_firebase_user,
        'is_email_verified': is_email_verified,
    }
    
    return render(request, 'accounts/profile.html', context)

@login_required
def verification_required_view(request):
    """View shown when email verification is required."""
    # Check if already verified through email_verified field
    if hasattr(request.user, 'email_verified') and request.user.email_verified:
        messages.success(request, _('Your email is already verified!'))
        return redirect('dashboard:home')
        
    # Check verification token
    verification_token = EmailVerificationToken.objects.filter(user=request.user).first()
    if verification_token and verification_token.verified:
        messages.success(request, _('Your email is already verified!'))
        return redirect('dashboard:home')
    
    # If no verification token exists, create one with verified=False
    if not verification_token:
        verification_token = EmailVerificationToken.objects.create(
            user=request.user,
            verified=False,
            expires_at=datetime.now() + timedelta(hours=48)
        )
    
    # Is Firebase user?
    is_firebase_user = request.user.password is None or request.user.password == ''
    
    context = {
        'is_firebase_user': is_firebase_user,
        'user': request.user,
    }
    
    return render(request, 'accounts/verification_required.html', context)

@login_required
def admin_dashboard(request):
    """Admin dashboard view with statistics and management tools."""
    # Only accessible by staff and superusers
    if not request.user.is_staff and not request.user.is_superuser:
        messages.error(request, _('You do not have permission to access the admin dashboard.'))
        return redirect('core:home')
    
    # Import models here to avoid circular imports
    from django.contrib.auth.models import User
    from courses.models import Course, Lesson, Progress
    
    # Gather statistics
    stats = {
        'users_count': User.objects.count(),
        'courses_count': Course.objects.count(),
        'lessons_count': Lesson.objects.count(),
        'completions_count': Progress.objects.filter(completed=True).count(),
    }
    
    # Get recent users with their verification status
    recent_users = User.objects.order_by('-date_joined')[:10]
    
    # Attach verification status to users
    for user in recent_users:
        user.verification = EmailVerificationToken.objects.filter(user=user).first()
    
    # Get recent courses
    recent_courses = Course.objects.order_by('-created_at')[:10]
    
    context = {
        'stats': stats,
        'recent_users': recent_users,
        'recent_courses': recent_courses,
    }
    
    return render(request, 'admin/dashboard.html', context)

@login_required
def user_management(request):
    """User management view for admin users."""
    # Only accessible by staff and superusers
    if not request.user.is_staff and not request.user.is_superuser:
        messages.error(request, _('You do not have permission to access user management.'))
        return redirect('core:home')
    
    from django.contrib.auth.models import User
    from django.core.paginator import Paginator
    from django.db.models import Q
    
    # Handle search and filters
    search_query = request.GET.get('search', '')
    verification_filter = request.GET.get('verification', '')
    usertype_filter = request.GET.get('usertype', '')
    
    # Start with all users
    users_query = User.objects.all().order_by('-date_joined')
    
    # Apply search if provided
    if search_query:
        users_query = users_query.filter(
            Q(username__icontains=search_query) | 
            Q(email__icontains=search_query) |
            Q(first_name__icontains=search_query) |
            Q(last_name__icontains=search_query)
        )
    
    # Apply verification filter
    if verification_filter:
        if verification_filter == 'verified':
            # Get users with verified email
            verified_user_ids = EmailVerificationToken.objects.filter(verified=True).values_list('user_id', flat=True)
            users_query = users_query.filter(id__in=verified_user_ids)
        elif verification_filter == 'unverified':
            # Get users with unverified email
            verified_user_ids = EmailVerificationToken.objects.filter(verified=True).values_list('user_id', flat=True)
            users_query = users_query.exclude(id__in=verified_user_ids)
            users_query = users_query.exclude(is_staff=True).exclude(is_superuser=True)  # Exclude admins
        elif verification_filter == 'auto':
            # Get admin users (auto-verified)
            users_query = users_query.filter(Q(is_staff=True) | Q(is_superuser=True))
    
    # Apply user type filter
    if usertype_filter:
        if usertype_filter == 'admin':
            users_query = users_query.filter(is_superuser=True)
        elif usertype_filter == 'staff':
            users_query = users_query.filter(is_staff=True, is_superuser=False)
        elif usertype_filter == 'regular':
            users_query = users_query.filter(is_staff=False, is_superuser=False)
    
    # Paginate results
    paginator = Paginator(users_query, 12)  # Show 12 users per page
    page_number = request.GET.get('page', 1)
    users_page = paginator.get_page(page_number)
    
    # Attach verification status to each user
    for user in users_page:
        user.verification = EmailVerificationToken.objects.filter(user=user).first()
    
    context = {
        'users': users_page,
        'search_query': search_query,
        'verification_filter': verification_filter,
        'usertype_filter': usertype_filter,
    }
    
    return render(request, 'admin/user_management.html', context)

@require_POST
def firebase_login(request):
    """Backend endpoint for Firebase login."""
    try:
        print("================ LOGIN ATTEMPT =================")
        # Get form data
        email = request.POST.get('email')
        firebase_uid = request.POST.get('firebase_uid')
        email_verified = request.POST.get('email_verified') == 'true'
        
        print(f"Login attempt for: {email}, verified: {email_verified}")
        
        if not email:
            print("Error: Missing email")
            return JsonResponse({'success': False, 'error': 'Email is required'})
        
        # Check if user exists in our Django database
        existing_user = User.objects.filter(email=email).first()
        
        if existing_user:
            print(f"Found existing user: {existing_user.username}, verified: {email_verified}")
            
            # Update the verification status to match Firebase's status
            if hasattr(existing_user, 'email_verified'):
                existing_user.email_verified = email_verified
                existing_user.save()
            
            # Update the verification token
            token = EmailVerificationToken.objects.filter(user=existing_user).first()
            if token:
                token.verified = email_verified
                token.save()
            else:
                # Create verification token record
                EmailVerificationToken.objects.create(
                    user=existing_user,
                    verified=email_verified,
                    expires_at=datetime.now() + timedelta(hours=48)
                )
            
            # Log in the user regardless of verification status
            login(request, existing_user)
            print(f"Logged in existing user: {existing_user.username}")
            
            # Decide where to redirect based on verification status
            redirect_url = '/dashboard/' if email_verified else '/accounts/verification-required/'
            
            return JsonResponse({
                'success': True,
                'message': 'Logged in successfully',
                'redirect_url': redirect_url,
                'verified': email_verified
            })
        else:
            print(f"No user found with email: {email}")
            # Auto create a user with this email if it doesn't exist
            # Use the email prefix as username
            base_username = email.split('@')[0]
            username = base_username
            
            # Ensure username is unique
            counter = 1
            while User.objects.filter(username=username).exists():
                username = f"{base_username}{counter}"
                counter += 1
            
            try:
                # Create the user without a password since we're using Firebase auth
                # Set is_active to True regardless of verification status
                new_user = User.objects.create_user(
                    username=username,
                    email=email,
                    password=None,  # No password for Firebase auth
                    is_active=True  # Always make active regardless of verification
                )
                if hasattr(new_user, 'email_verified'):
                    new_user.email_verified = email_verified
                    new_user.save()
                
                print(f"Auto-created new user: {username}, verified: {email_verified}")
                
                # Create verification token record with the actual verification status
                EmailVerificationToken.objects.create(
                    user=new_user,
                    verified=email_verified,
                    expires_at=datetime.now() + timedelta(hours=48)
                )
                
                # Log in the user regardless of verification status
                login(request, new_user)
                print(f"Logged in new auto-created user: {username}")
                
                # Decide where to redirect based on verification status
                redirect_url = '/dashboard/' if email_verified else '/accounts/verification-required/'
                
                return JsonResponse({
                    'success': True,
                    'message': 'Account created and logged in successfully',
                    'redirect_url': redirect_url,
                    'verified': email_verified
                })
                
            except Exception as create_error:
                print(f"Auto user creation error: {str(create_error)}")
                return JsonResponse({
                    'success': False, 
                    'error': f'Failed to create user: {str(create_error)}'
                })
            
    except Exception as e:
        print(f"Login error: {str(e)}")
        # Ensure we return valid JSON
        return JsonResponse({
            'success': False, 
            'error': f'Server error: {str(e)}'
        })

@require_POST
def firebase_register(request):
    """Backend endpoint for Firebase registration."""
    try:
        print("================ REGISTRATION ATTEMPT =================")
        # Get form data
        username = request.POST.get('username')
        email = request.POST.get('email')
        firebase_uid = request.POST.get('firebase_uid')
        email_verified = request.POST.get('email_verified') == 'true'
        
        print(f"Registration for: {email}, username: {username}, verified: {email_verified}")
        
        if not all([username, email]):
            missing = []
            if not username: missing.append('username')
            if not email: missing.append('email')
            error_msg = f"Missing fields: {', '.join(missing)}"
            print(f"Error: {error_msg}")
            return JsonResponse({'success': False, 'error': error_msg})
        
        # Check if user already exists
        if User.objects.filter(username=username).exists():
            print(f"Error: Username {username} already exists")
            return JsonResponse({'success': False, 'error': f'Username {username} already exists'})
        
        # Check if user with this email exists in our Django database
        django_user = User.objects.filter(email=email).first()
        
        if django_user:
            print(f"Error: Email {email} already exists in Django database")
            return JsonResponse({'success': False, 'error': 'Email already exists. Please login instead.'})
        
        try:
            # Create the user without a password, always set active
            user = User.objects.create_user(
                username=username,
                email=email,
                password=None,  # No password for Firebase auth
                is_active=True  # Always active
            )
            user.email_verified = email_verified
            user.save()
            
            print(f"Created new user: {username}, verified: {email_verified}")
            
            # Check if this should be an admin/staff user (could be based on email domain or other criteria)
            # For example, if email ends with your company domain
            if email.endswith('@yourcompany.com'):  # Replace with your actual domain check for admins
                user.is_staff = True
                user.save()
                print(f"User {username} set as staff member")
            
            # Create verification token record - use the actual verification status
            EmailVerificationToken.objects.create(
                user=user,
                verified=email_verified,
                expires_at=datetime.now() + timedelta(hours=48)
            )
            
            # Always log in user
            login(request, user)
            print(f"Logged in new user: {username}")
            
            # Decide where to redirect based on verification status
            redirect_url = '/dashboard/' if email_verified else '/accounts/verification-required/'
            
            return JsonResponse({
                'success': True, 
                'message': 'Account created and logged in successfully', 
                'redirect_url': redirect_url,
                'verified': email_verified
            })
            
        except Exception as create_error:
            print(f"User creation error: {str(create_error)}")
            return JsonResponse({
                'success': False, 
                'error': f'Failed to create user: {str(create_error)}'
            })
    
    except Exception as e:
        print(f"Registration error: {str(e)}")
        # Ensure we return valid JSON
        return JsonResponse({
            'success': False, 
            'error': f'Server error: {str(e)}'
        })

@login_required
def auto_verify_firebase_email(request):
    """Endpoint to manually verify a user's email in the backend database.
    
    This is a fallback mechanism used by admins if Firebase email verification is not working.
    """
    if not request.user.is_authenticated:
        if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            return JsonResponse({
                'success': False,
                'message': _('You must be logged in to verify your email.')
            })
        messages.error(request, _('You must be logged in to verify your email.'))
        return redirect('accounts:login')
    
    # Only allow admins to use this function
    if not request.user.is_staff and not request.user.is_superuser:
        if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            return JsonResponse({
                'success': False,
                'message': _('You do not have permission to manually verify emails.')
            })
        messages.error(request, _('You do not have permission to manually verify emails.'))
        return redirect('accounts:profile')
    
    # Get client IP address for logging
    ip_address = request.META.get('REMOTE_ADDR', None)
    
    try:
        # Check if there's a verification token record
        token = EmailVerificationToken.objects.filter(user=request.user).first()
        
        if token:
            # Set as verified
            token.verified = True
            token.save()
            
            # Log this verification
            VerificationAttempt.objects.create(
                user=request.user,
                ip_address=ip_address,
                success=True,
                method='manual_verify',
                error_message=None
            )
            
            if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                return JsonResponse({
                    'success': True,
                    'verified': True,
                    'message': _('Your email has been verified successfully!')
                })
                
            messages.success(request, _('Your email has been verified successfully!'))
        else:
            # Create new verification token
            EmailVerificationToken.objects.create(
                user=request.user,
                verified=True,
                expires_at=datetime.now() + timedelta(hours=48)
            )
            
            # Log this verification
            VerificationAttempt.objects.create(
                user=request.user,
                ip_address=ip_address,
                success=True,
                method='manual_verify',
                error_message=None
            )
            
            if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                return JsonResponse({
                    'success': True,
                    'verified': True,
                    'message': _('Your email has been verified successfully!')
                })
                
            messages.success(request, _('Your email has been verified successfully!'))
            
        return redirect('dashboard:home')
    except Exception as e:
        error_message = str(e)
        
        # Log the failed attempt
        VerificationAttempt.objects.create(
            user=request.user,
            ip_address=ip_address,
            success=False,
            method='manual_verify',
            error_message=error_message
        )
        
        if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            return JsonResponse({
                'success': False,
                'message': _('An error occurred while verifying your email: {}').format(error_message)
            })
            
        messages.error(request, _('An error occurred while verifying your email. Please try again.'))
        return redirect('accounts:profile')

@login_required
def refresh_firebase_verification(request):
    """Endpoint to refresh verification status from Firebase."""
    if not request.user.is_authenticated:
        if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            return JsonResponse({
                'success': False,
                'verified': False,
                'message': _('You must be logged in to refresh verification status.')
            })
        messages.error(request, _('You must be logged in to refresh verification status.'))
        return redirect('accounts:login')
    
    # Get client IP address
    ip_address = request.META.get('REMOTE_ADDR', None)
    error_message = None
    
    try:
        # Check if Firebase says user is verified
        firebase_verified = False
        
        try:
            # Initialize Firebase and check user verification status
            from edusite.firebase import initialize_firebase
            from firebase_admin import auth as firebase_auth
            
            initialize_firebase()
            
            # Get user by email
            try:
                firebase_user = firebase_auth.get_user_by_email(request.user.email)
                
                if firebase_user and hasattr(firebase_user, 'email_verified'):
                    firebase_verified = firebase_user.email_verified
                    logger.info(f"Firebase verification status for {request.user.email}: {firebase_verified}")
                else:
                    logger.warning(f"No Firebase verification status found for {request.user.email}")
                    firebase_verified = False
                    error_message = "No verification status found in Firebase"
            except Exception as e:
                logger.error(f"Error retrieving Firebase user: {str(e)}")
                firebase_verified = False
                error_message = str(e)
        except Exception as e:
            logger.error(f"Error checking Firebase verification: {str(e)}")
            firebase_verified = False
            error_message = str(e)
        
        # Log this verification attempt
        VerificationAttempt.objects.create(
            user=request.user,
            ip_address=ip_address,
            success=firebase_verified,
            method='firebase_check',
            error_message=error_message
        )
        
        # Update our database record
        token = EmailVerificationToken.objects.filter(user=request.user).first()
        
        if token:
            # Update token with the verification status from Firebase
            token.verified = firebase_verified
            token.save()
            logger.info(f"Updated verification status for {request.user.username} to: {firebase_verified}")
        else:
            # Create a new token with the verification status
            token = EmailVerificationToken.objects.create(
                user=request.user,
                verified=firebase_verified,
                expires_at=datetime.now() + timedelta(hours=48)
            )
            logger.info(f"Created verification token for {request.user.username} with status: {firebase_verified}")
        
        # Update the user.email_verified field if it exists
        if hasattr(request.user, 'email_verified'):
            request.user.email_verified = firebase_verified
            request.user.save()
        
        # Check if this is an AJAX request
        if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            return JsonResponse({
                'success': True,
                'verified': firebase_verified,
                'message': _('Verification status updated successfully.')
            })
            
        # Handle normal request
        if firebase_verified:
            messages.success(request, _('Your email has been verified successfully!'))
            return redirect('dashboard:home')
        else:
            messages.warning(request, _(
                'Your email is not yet verified. Please check your inbox for the verification email and click the link. '
                'After clicking the link, refresh this page or click the "Check Verification Status" button again.'
            ))
            return redirect('accounts:verification_required')
            
    except Exception as e:
        logger.exception(f"Error in refresh verification: {str(e)}")
        
        # Log the failed attempt
        VerificationAttempt.objects.create(
            user=request.user,
            ip_address=ip_address,
            success=False,
            method='firebase_check',
            error_message=str(e)
        )
        
        if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            return JsonResponse({
                'success': False,
                'verified': False,
                'message': _('Unable to verify account status. Please try again.')
            })
        messages.error(request, _('Unable to verify account status. Please try again.'))
        return redirect('accounts:verification_required')

@login_required
def check_verification_status(request):
    """Endpoint to check if user's email is verified."""
    if not request.user.is_authenticated:
        if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            return JsonResponse({
                'success': False,
                'verified': False,
                'message': _('You must be logged in to check verification status.')
            })
        messages.error(request, _('You must be logged in to check verification status.'))
        return redirect('accounts:login')
    
    # Get client IP address
    ip_address = request.META.get('REMOTE_ADDR', None)
    
    # Check verification status from database
    verification_token = EmailVerificationToken.objects.filter(user=request.user).first()
    verified = verification_token and verification_token.verified
    
    # Also check the user.email_verified field
    if not verified and hasattr(request.user, 'email_verified') and request.user.email_verified:
        verified = True
    
    # Log this check
    VerificationAttempt.objects.create(
        user=request.user,
        ip_address=ip_address,
        success=verified,
        method='auto_check',
        error_message=None
    )
    
    # Check if this is an AJAX request
    if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        return JsonResponse({
            'success': True,
            'verified': verified,
            'message': _('Verification status checked successfully.')
        })
        
    # Handle normal request
    if verified:
        messages.success(request, _('Your email has been verified successfully!'))
        return redirect('dashboard:home')
    else:
        messages.warning(request, _('Your email is not yet verified. Please check your inbox for a verification email.'))
        return redirect('accounts:verification_required')

@login_required
def delete_user_view(request, user_id):
    """View for deleting a user from the user management page."""
    # Only accessible by staff and superusers
    if not request.user.is_staff and not request.user.is_superuser:
        messages.error(request, _('You do not have permission to delete users.'))
        return redirect('core:home')
    
    try:
        # Get the user to delete
        user_to_delete = User.objects.get(pk=user_id)
        
        # Superusers can only be deleted by other superusers
        if user_to_delete.is_superuser and not request.user.is_superuser:
            messages.error(request, _('You do not have permission to delete a superuser.'))
            return redirect('accounts:user_management')
        
        # Can't delete yourself
        if user_to_delete.id == request.user.id:
            messages.error(request, _('You cannot delete your own account through this interface.'))
            return redirect('accounts:user_management')
        
        # Store the username for confirmation message
        username = user_to_delete.username
        
        # Delete the user
        user_to_delete.delete()
        
        # Success message
        messages.success(request, _(f'User "{username}" has been deleted successfully.'))
        
    except User.DoesNotExist:
        messages.error(request, _('User not found.'))
    except Exception as e:
        messages.error(request, _(f'Error deleting user: {str(e)}'))
    
    return redirect('accounts:user_management')

@login_required
def resend_verification_email(request):
    """Resend verification email to the user."""
    user = request.user
    is_ajax = request.headers.get('X-Requested-With') == 'XMLHttpRequest'
    
    success = False
    message = ""
    verified = False
    
    # For debugging: print recipient email address
    logger.info(f"Attempting to resend verification email to user {user.username} ({user.email})")
    
    try:
        # Check if already verified
        if hasattr(user, 'email_verified') and user.email_verified:
            success = True
            message = _("Your email is already verified!")
            verified = True
            
            if is_ajax:
                return JsonResponse({
                    'success': success,
                    'message': message,
                    'verified': verified
                })
            else:
                messages.success(request, message)
                return redirect('dashboard:home')
                
        # Also check verification token
        verification_token = EmailVerificationToken.objects.filter(user=user).first()
        if verification_token and verification_token.verified:
            success = True
            message = _("Your email is already verified!")
            verified = True
            
            if is_ajax:
                return JsonResponse({
                    'success': success,
                    'message': message,
                    'verified': verified
                })
            else:
                messages.success(request, message)
                return redirect('dashboard:home')
                
        # Generate verification token
        from django.utils.http import urlsafe_base64_encode
        from django.utils.encoding import force_bytes
        from django.contrib.auth.tokens import default_token_generator
        
        uid = urlsafe_base64_encode(force_bytes(user.pk))
        token = default_token_generator.make_token(user)
        
        # Build verification link
        verification_link = request.build_absolute_uri(
            reverse('accounts:verify_email', kwargs={'uidb64': uid, 'token': token})
        )
        
        # Debug: Print the verification link
        logger.info(f"Generated verification link: {verification_link}")
        
        # Send verification email
        subject = _("Verify your Edu313 account")
        from django.template.loader import render_to_string
        from django.utils.html import strip_tags
        
        context = {
            'user': user,
            'verification_link': verification_link,
            'site_name': 'Edu313',
            'now': datetime.now(),
        }
        
        html_message = render_to_string('accounts/email/verification_email.html', context)
        plain_message = strip_tags(html_message)
        
        # Debug: Check email settings
        logger.info(f"Email settings: FROM_EMAIL={settings.DEFAULT_FROM_EMAIL}, EMAIL_HOST={settings.EMAIL_HOST}")
        
        from_email = settings.DEFAULT_FROM_EMAIL
        to_email = user.email
        
        # Log attempt
        logger.info(f"Attempting to send verification email to {to_email}")
        
        try:
            # Send the email
            send_result = send_mail(
                subject,
                plain_message,
                from_email,
                [to_email],
                html_message=html_message,
                fail_silently=False
            )
            
            if send_result:
                # Log the success
                logger.info(f"Verification email sent successfully to {to_email}")
                
                # Update or create a verification attempt record
                ip_address = request.META.get('REMOTE_ADDR', None)
                VerificationAttempt.objects.create(
                    user=user,
                    ip_address=ip_address,
                    success=True,
                    method='email_sent',
                    error_message=None
                )
                
                # For debugging, show the link on the page for development/testing
                if settings.DEBUG:
                    debug_message = f"DEBUG MODE: Your verification link is: {verification_link}"
                    success = True
                    message = _(f"Verification email has been sent to your email address. Please check your inbox and spam folders. {debug_message}")
                else:
                    success = True
                    message = _("Verification email has been sent to your email address. Please check your inbox and spam folders.")
            else:
                # Log the failure
                logger.error(f"Failed to send verification email to {to_email} - send_mail returned {send_result}")
                success = False
                message = _("Failed to send verification email. Please try again or contact support.")
        except Exception as e:
            # Log the error
            logger.exception(f"Error sending verification email: {str(e)}")
            success = False
            message = _(f"Error sending verification email: {str(e)[:100]}... Please try again later or contact support.")
    except Exception as e:
        # Log the error
        logger.exception(f"Unexpected error in resend_verification_email: {str(e)}")
        success = False
        message = _(f"An unexpected error occurred: {str(e)[:100]}... Please try again later.")
    
    if is_ajax:
        return JsonResponse({
            'success': success,
            'message': message,
            'verified': verified
        })
    else:
        if success:
            messages.success(request, message)
        else:
            messages.error(request, message)
        
        return redirect('accounts:verification_required') 