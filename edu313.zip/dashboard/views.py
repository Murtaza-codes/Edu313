from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from courses.models import Course, Progress
from django.db.models import Count
from accounts.views import email_verified_required

@login_required
@email_verified_required
def dashboard_home(request):
    enrolled_courses = Course.objects.filter(students=request.user)
    
    courses_progress = []
    for course in enrolled_courses:
        progress = course.student_progress(request.user)
        lessons_completed = Progress.objects.filter(
            user=request.user,
            lesson__course=course,
            completed=True
        ).count()
        total_lessons = course.total_lessons()
        
        courses_progress.append({
            'course': course,
            'progress': progress,
            'completed': progress == 100,
            'lessons_completed': lessons_completed,
            'total_lessons': total_lessons
        })
    
    # Recent activity - last 5 lessons the user has interacted with
    recent_progress = Progress.objects.filter(
        user=request.user
    ).order_by('-last_watched')[:5]
    
    context = {
        'courses_progress': courses_progress,
        'total_courses': enrolled_courses.count(),
        'completed_courses': sum(1 for cp in courses_progress if cp['completed']),
        'in_progress_courses': sum(1 for cp in courses_progress if not cp['completed'] and cp['progress'] > 0),
        'recent_progress': recent_progress
    }
    
    return render(request, 'dashboard/home.html', context)

# Alias for dashboard_home to avoid confusion
home = dashboard_home 