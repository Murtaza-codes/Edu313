from django.db import models
from django.contrib.auth.models import User
from django.urls import reverse
from django.utils.text import slugify
import re
from googletrans import Translator

class Course(models.Model):
    title = models.CharField(max_length=200)
    slug = models.SlugField(max_length=255, unique=True, null=True, blank=True)
    description = models.TextField()
    thumbnail = models.ImageField(upload_to='courses/thumbnails/')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    students = models.ManyToManyField(User, related_name='enrolled_courses', blank=True)

    def __str__(self):
        return self.title

    def save(self, *args, **kwargs):
        # Generate slug from title if not provided
        if not self.slug:
            base_slug = slugify(self.title)
            slug = base_slug
            counter = 1
            # Check if slug exists and generate a unique one
            while Course.objects.filter(slug=slug).exists():
                slug = f"{base_slug}-{counter}"
                counter += 1
            self.slug = slug
        super().save(*args, **kwargs)

    def get_absolute_url(self):
        return reverse('courses:detail', kwargs={'slug': self.slug})

    def total_lessons(self):
        return self.lessons.count()

    def student_progress(self, user):
        completed_lessons = Progress.objects.filter(
            user=user,
            lesson__course=self,
            completed=True
        ).count()
        total_lessons = self.total_lessons()
        if total_lessons > 0:
            return (completed_lessons / total_lessons) * 100
        return 0

class Lesson(models.Model):
    course = models.ForeignKey(Course, related_name='lessons', on_delete=models.CASCADE)
    title = models.CharField(max_length=200)
    title_fa = models.CharField(max_length=200, blank=True, null=True, help_text="Persian title for the lesson")
    description = models.TextField()
    thumbnail = models.ImageField(upload_to='lessons/thumbnails/', blank=True, null=True)
    video_url = models.URLField(help_text="Enter the YouTube video URL")
    resources = models.TextField(blank=True, null=True, help_text="Add resources like books, code links, etc. Use format: title|url for each line")
    order = models.PositiveIntegerField()
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['order']
        unique_together = ['course', 'order']

    def __str__(self):
        return f"{self.course.title} - {self.title}"

    def get_absolute_url(self):
        return reverse('courses:lesson_detail', args=[str(self.course.slug), str(self.id)])

    def get_title(self, language_code='en'):
        """Get the appropriate title based on language code"""
        if language_code == 'fa':
            if self.title_fa:
                return self.title_fa
            # If no Persian title is provided, try to translate from English
            try:
                translator = Translator()
                translation = translator.translate(self.title, src='en', dest='fa')
                return translation.text
            except Exception as e:
                print(f"Translation error for lesson {self.id}: {str(e)}")
                return self.title
        return self.title

    def save(self, *args, **kwargs):
        # If no Persian title is provided and the title is in English, try to translate it
        if not self.title_fa and self.title:
            try:
                translator = Translator()
                translation = translator.translate(self.title, src='en', dest='fa')
                self.title_fa = translation.text
            except Exception as e:
                print(f"Translation error for lesson {self.id}: {str(e)}")
        super().save(*args, **kwargs)

    def get_video_id(self):
        """Extract YouTube video ID from URL"""
        if not self.video_url:
            return ''
            
        # Try to extract YouTube video ID using regex (most reliable method)
        youtube_regex = r'(?:youtube\.com\/(?:[^\/]+\/.+\/|(?:v|e(?:mbed)?)\/|.*[?&]v=)|youtu\.be\/)([^"&?\/\s]{11})'
        match = re.search(youtube_regex, self.video_url)
        
        if match:
            # Return just the video ID for Plyr
            return match.group(1)
            
        # Fallback methods if regex fails
        if 'youtube.com/watch' in self.video_url and 'v=' in self.video_url:
            try:
                return self.video_url.split('v=')[1].split('&')[0]
            except IndexError:
                pass
        elif 'youtu.be/' in self.video_url:
            try:
                return self.video_url.split('youtu.be/')[1].split('?')[0]
            except IndexError:
                pass
                
        # If all extraction methods fail, return empty string
        return ''
        
    def get_video_embed_url(self):
        """Convert YouTube URL to embed URL"""
        video_id = self.get_video_id()
        if video_id:
            return f'https://www.youtube.com/embed/{video_id}?autoplay=0&rel=0&cc_load_policy=1&cc_lang_pref=fa&hl=fa'
        return self.video_url

    def get_resources(self):
        """Parse resources text into a list of dictionaries with title and url"""
        if not self.resources:
            return []
        
        resource_list = []
        for line in self.resources.strip().split('\n'):
            if '|' in line:
                title, url = line.split('|', 1)
                resource_list.append({
                    'title': title.strip(),
                    'url': url.strip()
                })
        return resource_list

class Progress(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    lesson = models.ForeignKey(Lesson, on_delete=models.CASCADE)
    completed = models.BooleanField(default=False)
    last_watched = models.DateTimeField(auto_now=True)

    class Meta:
        unique_together = ['user', 'lesson']
        verbose_name_plural = 'Progress'

    def __str__(self):
        return f"{self.user.username} - {self.lesson.title}" 