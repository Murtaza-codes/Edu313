from django.contrib import admin
from django.utils.html import format_html
from django.db.models import Count
from django.urls import path
from django.template.response import TemplateResponse
from django import forms
from django.shortcuts import redirect, get_object_or_404
from django.contrib import messages
from .models import Course, Lesson, Progress
import re
from django.utils.safestring import mark_safe

class LessonInline(admin.TabularInline):
    model = Lesson
    extra = 1
    fields = ('title', 'order', 'video_url', 'thumbnail')
    readonly_fields = ('preview_video',)
    show_change_link = True
    
    def preview_video(self, obj):
        if obj.video_url:
            video_id = obj.get_video_id()
            if video_id:
                thumbnail_url = f"https://img.youtube.com/vi/{video_id}/mqdefault.jpg"
                return format_html('<a href="{0}" target="_blank"><img src="{1}" style="max-height: 60px;" /></a>', 
                                obj.video_url, thumbnail_url)
        return "No video URL"

# Form for adding YouTube videos quickly
class YouTubeVideoForm(forms.Form):
    course = forms.ModelChoiceField(queryset=Course.objects.all())
    title = forms.CharField(max_length=200)
    video_url = forms.URLField(
        label="YouTube Video URL",
        help_text="Enter the full YouTube URL (e.g., https://www.youtube.com/watch?v=VIDEO_ID)"
    )
    description = forms.CharField(
        widget=forms.Textarea(attrs={'rows': 8, 'style': 'width: 100%; max-width: 800px;'}),
        required=False,
        help_text="Enter a unique description for this episode. This will NOT be reused for other episodes."
    )
    resources = forms.CharField(
        widget=forms.Textarea(attrs={'rows': 5, 'style': 'width: 100%; max-width: 800px;'}),
        required=False,
        help_text="Enter resources in format: title|url (one per line). Example: 'GitHub Repository|https://github.com/example/repo'"
    )
    order = forms.IntegerField(
        initial=1,
        help_text="Position of this lesson in the course"
    )

# Simplified form for Lesson admin
class LessonAdminForm(forms.ModelForm):
    description = forms.CharField(
        widget=forms.Textarea(
            attrs={
                'rows': 15, 
                'cols': 100, 
                'style': 'width: 100%; max-width: 800px; font-size: 14px;',
                'class': 'vLargeTextField'
            }
        ),
        required=False,
        help_text="Enter the episode description here. Each episode has its own unique description."
    )
    
    resources = forms.CharField(
        widget=forms.Textarea(
            attrs={
                'rows': 10, 
                'cols': 100, 
                'style': 'width: 100%; max-width: 800px; font-size: 14px;',
                'class': 'vLargeTextField'
            }
        ),
        required=False,
        help_text="Enter resources in the format: title|url (one per line). Example: 'GitHub Repository|https://github.com/example/repo'"
    )
    
    class Meta:
        model = Lesson
        fields = '__all__'
        widgets = {
            'title': forms.TextInput(attrs={'style': 'width: 100%; max-width: 800px;', 'size': 80}),
        }

@admin.register(Course)
class CourseAdmin(admin.ModelAdmin):
    list_display = ('title', 'created_at', 'updated_at', 'lesson_count', 'student_count', 'thumbnail_preview')
    list_filter = ('created_at', 'updated_at')
    search_fields = ('title', 'description')
    readonly_fields = ('thumbnail_preview',)
    inlines = [LessonInline]
    actions = ['duplicate_course']
    
    def get_urls(self):
        urls = super().get_urls()
        custom_urls = [
            path('course-dashboard/', self.admin_site.admin_view(self.course_dashboard_view), name='course-dashboard'),
            path('add-youtube-video/', self.admin_site.admin_view(self.add_youtube_video_view), name='add-youtube-video'),
        ]
        return custom_urls + urls
    
    def course_dashboard_view(self, request):
        courses = Course.objects.annotate(
            num_lessons=Count('lessons'),
            num_students=Count('students')
        ).order_by('-created_at')
        
        context = {
            'title': 'Course Dashboard',
            'courses': courses,
        }
        return TemplateResponse(request, 'admin/courses/course_dashboard.html', context)
    
    def add_youtube_video_view(self, request):
        if request.method == 'POST':
            form = YouTubeVideoForm(request.POST)
            if form.is_valid():
                course = form.cleaned_data['course']
                
                # Create the lesson with the YouTube URL
                lesson = Lesson.objects.create(
                    course=course,
                    title=form.cleaned_data['title'],
                    description=form.cleaned_data['description'],
                    resources=form.cleaned_data['resources'],
                    video_url=form.cleaned_data['video_url'],
                    order=form.cleaned_data['order'],
                )
                
                messages.success(request, f"Successfully added video '{lesson.title}' to course '{course.title}'")
                
                # Check if user wants to add another video
                if 'add_another' in request.POST:
                    return redirect('admin:add-youtube-video')
                else:
                    return redirect('admin:courses_lesson_change', lesson.id)
        else:
            # Prefill course if provided in GET parameters
            initial = {}
            course_id = request.GET.get('course_id')
            if course_id:
                try:
                    course = Course.objects.get(id=course_id)
                    initial['course'] = course
                    
                    # Auto-set order to next available position
                    next_order = 1
                    last_lesson = Lesson.objects.filter(course=course).order_by('-order').first()
                    if last_lesson:
                        next_order = last_lesson.order + 1
                    initial['order'] = next_order
                except Course.DoesNotExist:
                    pass
                
            form = YouTubeVideoForm(initial=initial)
        
        context = {
            'title': 'Add YouTube Video',
            'form': form,
            'courses': Course.objects.all(),
        }
        return TemplateResponse(request, 'admin/courses/add_youtube_video.html', context)
    
    def lesson_count(self, obj):
        return obj.lessons.count()
    lesson_count.short_description = 'Lessons'
    
    def student_count(self, obj):
        return obj.students.count()
    student_count.short_description = 'Students'
    
    def thumbnail_preview(self, obj):
        if obj.thumbnail:
            return format_html('<img src="{0}" style="max-height: 100px; max-width: 200px;" />', obj.thumbnail.url)
        return "No thumbnail"
    thumbnail_preview.short_description = 'Thumbnail Preview'
    
    def duplicate_course(self, request, queryset):
        for course in queryset:
            # Create a new course with the same attributes
            new_course = Course.objects.create(
                title=f"Copy of {course.title}",
                description=course.description,
                thumbnail=course.thumbnail
            )
            
            # Duplicate lessons
            for lesson in course.lessons.all():
                Lesson.objects.create(
                    course=new_course,
                    title=lesson.title,
                    description=lesson.description,
                    resources=lesson.resources,
                    thumbnail=lesson.thumbnail,
                    video_url=lesson.video_url,
                    order=lesson.order
                )
            
            self.message_user(request, f"Course '{course.title}' was duplicated as 'Copy of {course.title}'")
    duplicate_course.short_description = "Duplicate selected courses"

@admin.register(Lesson)
class LessonAdmin(admin.ModelAdmin):
    form = LessonAdminForm
    list_display = ('title', 'course', 'order', 'video_preview', 'has_description', 'has_resources', 'created_at', 'thumbnail_preview')
    list_filter = ('course', 'created_at')
    search_fields = ('title', 'description', 'course__title')
    readonly_fields = ('video_preview', 'thumbnail_preview')
    actions = ['duplicate_lesson']
    save_on_top = True
    
    # Add a custom "Add Episode" button at the top of the change list
    change_list_template = 'admin/courses/lesson_change_list.html'
    
    fieldsets = (
        ('Episode Details', {
            'fields': ('course', 'title', 'order'),
            'classes': ('wide',),
        }),
        ('Episode Description', {
            'fields': ('description',),
            'classes': ('wide',),
            'description': mark_safe('<strong>Each episode can have its own unique description.</strong> '
                          'Changes made here will only affect this episode.'),
        }),
        ('Episode Resources', {
            'fields': ('resources',),
            'classes': ('wide',),
            'description': mark_safe('<strong>Add links to books, code, and other resources.</strong> '
                          'Format: title|url (one per line)'),
        }),
        ('Episode Media', {
            'fields': ('thumbnail', 'thumbnail_preview', 'video_url', 'video_preview'),
            'classes': ('wide', 'collapse', 'in'),
            'description': 'Upload a thumbnail image and enter the YouTube video URL.',
        }),
    )
    
    def has_description(self, obj):
        """Check if lesson has a description"""
        if obj.description and len(obj.description.strip()) > 0:
            return True
        return False
    has_description.boolean = True
    has_description.short_description = 'Has Description'
    
    def has_resources(self, obj):
        """Check if lesson has resources"""
        if obj.resources and len(obj.resources.strip()) > 0:
            return True
        return False
    has_resources.boolean = True
    has_resources.short_description = 'Has Resources'
    
    def video_preview(self, obj):
        if obj.video_url:
            video_id = obj.get_video_id()
            if video_id:
                return format_html(
                    '<div style="max-width: 400px;">'
                    '<div style="position: relative; padding-bottom: 56.25%; height: 0; overflow: hidden;">'
                    '<iframe style="position: absolute; top: 0; left: 0; width: 100%; height: 100%;" '
                    'src="https://www.youtube.com/embed/{0}" frameborder="0" '
                    'allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>'
                    '</div></div>', video_id
                )
        return "No video URL provided"
    video_preview.short_description = 'Video Preview'
    
    def thumbnail_preview(self, obj):
        if obj.thumbnail:
            return format_html('<img src="{0}" style="max-height: 100px; max-width: 200px;" />', obj.thumbnail.url)
        return "No thumbnail"
    thumbnail_preview.short_description = 'Thumbnail Preview'
    
    def duplicate_lesson(self, request, queryset):
        for lesson in queryset:
            Lesson.objects.create(
                course=lesson.course,
                title=f"Copy of {lesson.title}",
                description=lesson.description,
                resources=lesson.resources,
                thumbnail=lesson.thumbnail,
                video_url=lesson.video_url,
                order=lesson.order
            )
            self.message_user(request, f"Lesson '{lesson.title}' was duplicated as 'Copy of {lesson.title}'")
    duplicate_lesson.short_description = "Duplicate selected lessons"

@admin.register(Progress)
class ProgressAdmin(admin.ModelAdmin):
    list_display = ('user', 'lesson', 'completed', 'last_watched')
    list_filter = ('completed', 'last_watched', 'lesson__course')
    search_fields = ('user__username', 'lesson__title', 'lesson__course__title')
    readonly_fields = ('last_watched',) 