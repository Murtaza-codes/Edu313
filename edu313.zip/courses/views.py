from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from django.contrib.auth.mixins import LoginRequiredMixin
from django.views.generic import ListView, DetailView
from django.http import JsonResponse, HttpResponse
from django.views.decorators.http import require_POST
from django.urls import reverse
from .models import Course, Lesson, Progress
from django.contrib import messages
from accounts.views import email_verified_required
from accounts.models import EmailVerificationToken

class CourseListView(ListView):
    model = Course
    template_name = 'courses/course_list.html'
    context_object_name = 'courses'
    paginate_by = 12

class CourseDetailView(DetailView):
    model = Course
    template_name = 'courses/course_detail.html'
    context_object_name = 'course'
    slug_field = 'slug'
    slug_url_kwarg = 'slug'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        # Add lessons to the context
        context['lessons'] = self.object.lessons.all()
        if self.request.user.is_authenticated:
            # Check if user is enrolled
            context['is_enrolled'] = self.request.user in self.object.students.all()
            # Calculate progress only if the user is enrolled
            context['progress'] = self.object.student_progress(self.request.user)
            
            # Admin users are automatically considered verified
            if self.request.user.is_staff or self.request.user.is_superuser:
                context['is_email_verified'] = True
            else:
                # Check if email is verified
                verification = EmailVerificationToken.objects.filter(user=self.request.user).first()
                context['is_email_verified'] = verification and verification.verified
        return context

@login_required
@email_verified_required
def lesson_detail(request, course_slug, lesson_id):
    course = get_object_or_404(Course, slug=course_slug)
    lesson = get_object_or_404(Lesson, id=lesson_id, course=course)
    
    # Get or create progress
    progress, created = Progress.objects.get_or_create(
        user=request.user,
        lesson=lesson
    )
    
    # Get next and previous lessons
    next_lesson = Lesson.objects.filter(course=course, order__gt=lesson.order).first()
    prev_lesson = Lesson.objects.filter(course=course, order__lt=lesson.order).last()
    
    # Get all lessons for the course to display in the sidebar
    course_lessons = course.lessons.all()
    
    # Calculate course progress
    course_progress = course.student_progress(request.user)
    
    context = {
        'course': course,
        'lesson': lesson,
        'progress': progress,
        'next_lesson': next_lesson,
        'prev_lesson': prev_lesson,
        'course_lessons': course_lessons,
        'course_progress': course_progress,
    }
    return render(request, 'courses/lesson_detail.html', context)

@login_required
@require_POST
def enroll_course(request, course_slug):
    course = get_object_or_404(Course, slug=course_slug)
    if request.user not in course.students.all():
        course.students.add(request.user)
        messages.success(request, f"You have successfully enrolled in {course.title}!")
    else:
        messages.info(request, f"You are already enrolled in {course.title}.")
    return redirect('courses:detail', slug=course_slug)

@login_required
@require_POST
def mark_complete(request, lesson_id):
    lesson = get_object_or_404(Lesson, id=lesson_id)
    progress, created = Progress.objects.get_or_create(
        user=request.user,
        lesson=lesson
    )
    progress.completed = True
    progress.save()
    
    # If the request expects JSON, return a JSON response
    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
        return JsonResponse({
            'success': True,
            'progress': lesson.course.student_progress(request.user)
        })
    
    # Otherwise redirect back to the lesson page with a success message
    messages.success(request, f"Great job! You've completed '{lesson.title}'")
    return redirect('courses:lesson_detail', course_slug=lesson.course.slug, lesson_id=lesson.id) 