from django import template
from django.utils.translation import gettext_lazy as _

register = template.Library()

@register.simple_tag
def compile_translations():
    """Force Django to compile translations by accessing some translated strings."""
    # Access a few strings to make sure they're compiled
    dummy1 = _("Home")
    dummy2 = _("Courses")
    dummy3 = _("About")
    dummy4 = _("Contact")
    dummy5 = _("Dashboard")
    dummy6 = _("Login")
    dummy7 = _("Register")
    return ""  # Return empty string so it doesn't output anything in templates 