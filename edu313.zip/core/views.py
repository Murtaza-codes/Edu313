from django.shortcuts import render
from courses.models import Course
from django.http import JsonResponse
from django.middleware.csrf import get_token
from django.views.decorators.http import require_GET

def home(request):
    featured_courses = Course.objects.all()[:3]
    return render(request, 'core/home.html', {'featured_courses': featured_courses})

def about(request):
    return render(request, 'core/about.html')

def contact(request):
    return render(request, 'core/contact.html')

def privacy(request):
    return render(request, 'core/privacy.html')

def terms(request):
    return render(request, 'core/terms.html')

def waiting(request):
    return render(request, 'waiting.html')

@require_GET
def csrf_refresh(request):
    """View to refresh CSRF token via AJAX."""
    return JsonResponse({'csrfToken': get_token(request)}) 